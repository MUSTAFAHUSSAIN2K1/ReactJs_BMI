import "./App.css";
import React, { useState } from "react";
function App() {
  // reload
  let reload = () => {
    window.location.reload();
  };

  //Logic
  let calcBmi = (e) => {
      e.preventDefault();

    if (weight === 0 || height === 0) {
      alert("please enter a valid weight and height");
    } else {
      let bmi = (weight / (height * height)) * 703;
      setBmi(bmi.toFixed(1));

      if (bmi < 25) {
        setMessage("you are under weight");
      } else if (bmi >= 25 && bmi < 30) {
        setMessage("you are a  healthy weight");
      } else {
        setMessage("you are over weight");
      }
    }
  };

  //making state of our application
  const [weight, setWeight] = useState(0);
  const [height, setHeight] = useState(0);
  const [bmi, setBmi] = useState("");
  const [messgae, setMessage] = useState("");

  return (
    <div className="container">
      <h2 style={{color:"white" , padding:0}}> BMI CALCULATOR</h2>
      <form onSubmit={calcBmi}>
        <div className="fields">
          <label> weight (lbs) </label>
          <input
            type="text"
            placeholder="Enter weight value"
            value={weight}
            onChange={(e) => {
              setWeight(e.target.value);
            }}
          />
        </div>
        <div className="fields">
          <label> Height (inches) </label>
          <input
            type="text"
            placeholder="Enter height value"
            value={height}
            onChange={(e) => {
              setHeight(e.target.value);
            }}
          />
        </div>
        <div>
          <button className="btn" type="submit">
            {" "}
            Submit{" "}
          </button>
          <button className="btn btn-outline" onClick={reload} type="submit">
            {" "}
            Reload
          </button>
        </div>
        <div className="center">
          <h3>Your BMI is :{bmi}</h3>
          <p>{messgae}</p>
        </div>
      </form>
    </div>
  );
}

export default App;
